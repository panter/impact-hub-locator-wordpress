<iframe 
    class="hubs-iframe" 
    src="<?php echo $iframeUrl;?>"
    allow="geolocation">
</iframe>